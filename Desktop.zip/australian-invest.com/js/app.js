function rotateNotifications(peopleArray) {
 let index = Math.floor(Math.random() * peopleArray.length),
  name = peopleArray[index].name.first + ' ' + peopleArray[index].name.last.charAt(0) + '.',
  image = peopleArray[index].picture.large,
  amount = '$' + Math.floor(50 + Math.random() * 200),
  delay = 3000 + Math.random() * 6000,
  wrapper = $('#notifications');
 wrapper.removeClass('hidden');
 wrapper.find('[data-name]').text(name);
 wrapper.find('[data-image]').attr('src', image);
 wrapper.find('[data-amount]').text(amount);
 setTimeout(function () {
  rotateNotifications(peopleArray);
 }, delay);
}

$.ajax({
 url: "https://get.geojs.io/v1/ip/geo.js",
 dataType: "jsonp",
 success: function (data) {
  // console.log(data)
  let countryIso = data.country_code;
  let num = 10;

  $('.country-name-custom')
   .css('color', '#FFB612')
   .text(data.country);

  $.ajax({
   url: `https://randomuser.me/api/?results=${num}&nat=${countryIso}`,
   dataType: 'json',
   success: function (data) {
    rotateNotifications(data.results)
   },
   error: function () {
    console.log('ERROR')
   }
  });

  $('.flag')
   .css("width", "80px")
   .css("height", "auto")
   .css("border", "none")
   .attr("src", `https://www.countryflags.io/${countryIso}/flat/64.png`);
 },
 error: function () {
  console.log('ERROR')
 }
});

const totalSum = document.querySelectorAll('.carousel__item-sum');
const totalPercent = document.querySelectorAll('.carousel__item-sum-under');
const title = document.querySelectorAll('.carousel__item-title');
const carouselImg = document.querySelectorAll('.carousel__img');

fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=binancecoin%2Csolana%2Cethereum%2Cbitcoin%2Ccardano%2Cdogecoin%2Ctether%2Cusd-coin%2Cripple&order=market_cap_desc&per_page=100&page=1&sparkline=false')
 .then(response => response.json())
 .then(data => {

  function getRandomArbitrary(min, max) {
   return ~~(Math.random() * (max - min)) + min;
  }

  let positiveGraph = ['./images/img1.png', './images/img2.png', './images/img4.png', './images/img5.png', './images/img7.png', './images/img9.png', './images/img10.png', './images/img12.png', './images/img13.png'];
  let negativeGraph = ['./images/img3.png', './images/img6.png', './images/img8.png', './images/img11.png', './images/img14.png', './images/img15.png'];

  let imageChange = (priceChange) => {
   if (priceChange >= 0) {
    return positiveGraph[getRandomArbitrary(1, 9)]
   } else {
    return negativeGraph[getRandomArbitrary(1, 6)]
   }
  }
  data.forEach(coin => {
   const coinName = coin.id;
   const priceChange = parseFloat(coin.price_change_percentage_24h).toFixed(2);
   title.forEach(item => {
    const name = item.dataset.name;

    if (coinName === name) {
     item.nextElementSibling.textContent = "$" + coin.current_price;
     item.nextElementSibling.nextElementSibling.src = imageChange(priceChange);
     item.nextElementSibling.nextElementSibling.nextElementSibling.innerHTML = (priceChange >= 0 ? `<span style="color: #4CB050" class="carousel__item-sum-under">${priceChange}%</span>` : `<span style="color: #EF6430" class="carousel__item-sum-under">${priceChange}%</span>`);
    }
   });
  });
 });