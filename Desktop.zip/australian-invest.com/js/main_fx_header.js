// Phone
jQuery(function ($) {
    //header
    let didScroll;
    let lastScrollTop = 0;
    let navbarHeight = $('#header').outerHeight();

    $(window).scroll(function (event) {
        didScroll = true;
    });

    setInterval(function () {
        if (didScroll) {
            hasScrolled();
            didScroll = false;
        }
    }, 250);

    function hasScrolled() {
        let st = $(window).scrollTop();
        if (st > lastScrollTop && st > navbarHeight) {
            $('#header').removeClass('header-show').addClass('header-hide');
        } else {
            if (st + $(window).height() < $(document).height()) {
                $('#header').removeClass('header-hide').addClass('header-show');
            }
        }
        lastScrollTop = st;
    }

    $('.modal').on('shown.bs.modal', function (e) {
        $(this).find('#forms_user_phone_number').css('paddingLeft', parseInt($(this).find('.dial-code-text').width()) + 51);
    });

    // symbols array
    var symbolsArr = [
        "AAPL.US",
        "ADBE.US",
        "AMZN.US",
        "BABA.US",
        "HOG.US",
        "CSCO.US",
        "DIS.US",
        "F.US",
        "KO.US",
        "FB.US",
        "INTC.US",
        "FDX.US",
        "GOOG.US",
        "MA.US"
    ];

    // charts container
    var container = document.getElementById("card-charts-container");
    // each symbols array

    //  $.each(symbolsArr, function(key, symbol) {
    //      $.getJSON(
    //          'https://api.prod.amarkets.dev/v1/restapi/history?symbol='+symbol+'&resolution=43200', function(data) {
    //              // elements for data
    //              var element = document.createElement("DIV");
    //              element.className += "card-chart";
    //              element.dataset.symbol = symbol;

    //              var symbolElm = document.createElement("DIV");
    //              symbolElm.className += "symbol";
    //              symbolElm.dataset.symbol = symbol;
    //              symbolElm.setAttribute('alt', symbol);
    //              symbolElm.setAttribute('title', symbol);

    //              var valuesElm = document.createElement("DIV");
    //              valuesElm.className += "values";

    //              var chartElm = document.createElement("DIV");
    //              chartElm.className += "chart";

    //              var percentElm = document.createElement("DIV");
    //              percentElm.className += "percentage";

    //              var button = document.createElement("A");
    //              button.href = "#"
    //              if (container.classList.contains("en")) {
    //                  button.innerHTML = "Invest";
    //              } else if (container.classList.contains("ar")) {
    //                  button.innerHTML = "Ш§ШіШЄШ«Щ…Ш±";
    //              } else if (container.classList.contains("fas")) {
    //                  button.innerHTML = "ШіШ±Щ…Ш§ЫЊЩ‡вЂЊЪЇШ°Ш§Ш±ЫЊ ";
    //              } else if (container.classList.contains("es")) {
    //                  button.innerHTML = "Invertir";
    //              } else if (container.classList.contains("tr")) {
    //                  button.innerHTML = "YatД±rД±m yap";
    //              } else {
    //                  button.innerHTML = "РРЅРІРµСЃС‚РёСЂРѕРІР°С‚СЊ";
    //              }
    //              button.className += "button";
    //              button.dataset.toggle = "modal";
    //              button.dataset.target = "#demo-modal";

    //              container.appendChild(element);

    //              // charts options
    //              var chart = LightweightCharts.createChart(chartElm, {
    //                  width: 420,
    //                  height: 140,
    //                  priceScale: {
    //                      position: 'none',
    //                      borderVisible: false,
    //                      scaleMargins: {
    //                          top: 0.1,
    //                          bottom: 0.1,
    //                      },
    //                  },
    //                  handleScroll: {
    //                      mouseWheel: false,
    //                      pressedMouseMove: false,
    //                  },
    //                  handleScale: {
    //                      axisPressedMouseMove: false,
    //                      mouseWheel: false,
    //                      pinch: false,
    //                  },
    //                  timeScale: {
    //                      borderVisible: false,
    //                      visible: false,
    //                  },
    //                  grid: {
    //                      vertLines: {
    //                          visible: false,
    //                      },
    //                      horzLines: {
    //                          visible: false,
    //                      },
    //                  },
    //                  layout: {
    //                      backgroundColor: '#fff',
    //                  },
    //                  localization: {
    //                      dateFormat: 'dd/MM/yy',
    //                      locale: 'ru-RU',
    //                  },
    //              });

    //              // variables
    //              var t = data.t, c = data.c, o = data.o, h = data.h, l = data.l, v = data.v, id = symbol, bid = data.c[data.c.length-1], pbid = data.c[data.c.length-2], symbolsPush = [];

    //              // to calculate the difference in percentage
    //              var percentage = (((bid - pbid) / pbid) * 100).toFixed(2);

    //              // data foreach
    //              var i;
    //              for (i = 0; i < t.length; ++i) {
    //                  var symbolsData = {time: t[i], open: o[i], high: h[i], low: l[i], close: c[i]};
    //                  symbolsPush.push(symbolsData);
    //              }

    //              // change the color depending on the percentage
    //              var color, tColor, condition;
    //              if (percentage >= 0) {
    //                  color = 'rgb(76, 176, 80)';
    //                  tColor = 'rgba(76, 176, 80, 0.1)';
    //                  element.className += " positive";
    //                  condition = "+";
    //              } else {
    //                  color = 'rgb(238, 89, 33)';
    //                  tColor = 'rgba(238, 89, 33, 0.01)';
    //                  element.className += " negative";
    //                  condition = "";
    //              }

    //              // append values
    //              $(symbolElm).append($('<span>', {
    //                  html: symbol,
    //                  // attr: ({data: symbol}),
    //                  // alt: symbol,
    //                  // title: symbol,
    //              }));
    //              $(valuesElm).append($('<div>', {
    //                  class: 'values-container',
    //                  attr: ({data: id}),
    //                  html: '<span>' + id + '</span>' + '<span>' + '$' + bid + '</span>',
    //              }));
    //              $(percentElm).append($('<span>', {
    //                  html: condition + percentage + "%" + '*'
    //              }));

    //              // chart visual style
    //              var areaSeries = chart.addAreaSeries({
    //                  priceLineVisible: false,
    //                  // topColor: 'rgb(255, 255, 255)',
    //                  topColor: tColor,
    //                  bottomColor: 'rgb(255, 255, 255)',
    //                  lineColor: color,
    //                  lineWidth: 2,
    //              });

    //              // chart additional options
    //              areaSeries.setData(symbolsPush);
    //              chart.disableBranding();
    //              chart.timeScale().fitContent();

    //              // add data to elements
    //              element.innerHTML += symbolElm.outerHTML + valuesElm.outerHTML + percentElm.outerHTML + button.outerHTML;
    //              // add chart to chart container
    //              element.appendChild(chartElm);

    //              // total symbols
    //              total_symbols = symbolsArr.length - 1;
    //              // run slider
    //              if (key === total_symbols) {
    //                  $('.owl-carousel').owlCarousel({
    //                      nav: false,
    //                      pagination: false,
    //                      dots: true,
    //                      responsive:{
    //                          0: {
    //                              items:1
    //                          },
    //                          576: {
    //                              items:2
    //                          },
    //                          768: {
    //                              items:2
    //                          },
    //                          992: {
    //                              items:3
    //                          },
    //                          1200: {
    //                              items:4
    //                          }
    //                      }
    //                  });
    //                  $('#card-charts-container').css('display','flex');
    //              }
    //          });
    //  });
    //  $('.carouser-chart-container').css('height', 'auto');
});



// symbols array
var symbolsECN = [
    [0],
    [1],
    [2],
];

